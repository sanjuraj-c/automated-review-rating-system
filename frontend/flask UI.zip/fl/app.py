import os
import re
import numpy as np
from flask import Flask, render_template, request, flash
import joblib
import pickle
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences

app = Flask(__name__)
app.secret_key = "replace-with-a-secure-random-key"

# -------------- CONFIG --------------
MODEL_A_PATH = "lstm_balanced_review_model1"
TOKENIZER_A_PATH = "tokenizer_lstm_balanced.pkl"
LABEL_A_PATH = "label_encoder_lstm_balanced.pkl"
MAXLEN_A = 128  # Must match training of Model A

MODEL_B_PATH = "lstm_review_classifier"
TOKENIZER_B_PATH = "tokenizer.pkl"
LABEL_B_PATH = "label_encoder.pkl"
MAXLEN_B = 128  # Must match training of Model B


# -------------- UTILITIES --------------
def clean_text(text: str) -> str:
    """Clean and normalize the input text."""
    if not isinstance(text, str):
        return ""
    s = text.strip().lower()
    s = re.sub(r"http\S+|www\S+", "", s)  # remove URLs
    s = re.sub(r"[^a-z0-9\s\.\,\!\?\'\"-]", " ", s)  # keep basic punctuation
    s = re.sub(r"\s+", " ", s).strip()
    return s


def valid_review(text: str, min_words: int = 2) -> bool:
    """Ensure review has a minimum number of words."""
    cleaned = re.sub(r'[^a-zA-Z\s]', ' ', text)
    words = [w for w in cleaned.split() if len(w) > 0]
    return len(words) >= min_words


# -------------- LOAD MODELS --------------
try:
    print("Loading Model A...")
    model_a = tf.keras.models.load_model(MODEL_A_PATH)
    tokenizer_a = joblib.load(TOKENIZER_A_PATH)
    label_encoder_a = joblib.load(LABEL_A_PATH)
    print("Model A loaded.")
except Exception as e:
    model_a = None
    tokenizer_a = None
    label_encoder_a = None
    print("Warning: Model A failed to load:", e)

try:
    print("Loading Model B...")
    model_b = tf.keras.models.load_model(MODEL_B_PATH)
    with open(TOKENIZER_B_PATH, "rb") as fh:
        tokenizer_b = pickle.load(fh)
    label_encoder_b = joblib.load(LABEL_B_PATH)
    print("Model B loaded.")
except Exception as e:
    model_b = None
    tokenizer_b = None
    label_encoder_b = None
    print("Warning: Model B failed to load:", e)


# -------------- PREDICTION ROUTINE --------------
def predict_with_model_a(text: str):
    """Predict label with Model A."""
    if model_a is None or tokenizer_a is None or label_encoder_a is None:
        return None, 0.0
    seq = tokenizer_a.texts_to_sequences([text])
    pad = pad_sequences(seq, maxlen=MAXLEN_A, padding="post", truncating="post")
    if pad.shape[1] != MAXLEN_A:
        pad = pad[:, :MAXLEN_A]
    probs = model_a.predict(pad, verbose=0)[0]
    idx = int(np.argmax(probs))
    label = label_encoder_a.inverse_transform([idx])[0]
    confidence = float(probs[idx])
    return label, confidence


def predict_with_model_b(text: str):
    """Predict label with Model B."""
    if model_b is None or tokenizer_b is None or label_encoder_b is None:
        return None, 0.0
    seq = tokenizer_b.texts_to_sequences([text])
    pad = pad_sequences(seq, maxlen=MAXLEN_B, padding="post", truncating="post")
    if pad.shape[1] != MAXLEN_B:
        pad = pad[:, :MAXLEN_B]
    probs = model_b.predict(pad, verbose=0)[0]
    idx = int(np.argmax(probs))
    label = label_encoder_b.inverse_transform([idx])[0]
    confidence = float(probs[idx])
    return label, confidence


def model_status():
    """Return a small status dict to show on the UI."""
    return {
        "A": model_a is not None and tokenizer_a is not None and label_encoder_a is not None,
        "B": model_b is not None and tokenizer_b is not None and label_encoder_b is not None
    }


# -------------- FLASK ROUTES --------------
@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", result=None, status=model_status())


@app.route("/predict", methods=["POST"])
def predict():
    review = request.form.get("review", "")
    model_choice = request.form.get("model_choice", "A").upper()
    cleaned = clean_text(review)

    if not review.strip():
        flash("Please enter a review.", "warning")
        return render_template("index.html", result=None, status=model_status())

    if not valid_review(review):
        flash("Please enter a meaningful review (at least 2 words).", "danger")
        return render_template("index.html", result=None, status=model_status())

    if model_choice == "A":
        label, conf = predict_with_model_a(cleaned)
    else:
        label, conf = predict_with_model_b(cleaned)

    if label is None:
        flash(f"Model {model_choice} is not loaded or failed to process the input.", "danger")
        return render_template("index.html", result=None, status=model_status())

    result = {
        "model_choice": model_choice,
        "label": str(label),
        "confidence": round(conf * 100, 2),
        "example_note": "Tip: try short clear reviews like 'Great product, very comfortable' or 'Poor quality, broke fast'"
    }

    return render_template("index.html", result=result, status=model_status())


@app.route("/health")
def health():
    return model_status()


if __name__ == "__main__":
    app.run(debug=True, port=8501)
